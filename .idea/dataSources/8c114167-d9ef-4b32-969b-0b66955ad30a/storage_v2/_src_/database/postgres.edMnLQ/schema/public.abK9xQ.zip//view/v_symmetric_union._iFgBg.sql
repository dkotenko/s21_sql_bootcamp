create view v_symmetric_union(person_id) as
WITH r AS (SELECT person_visits.id,
                  person_visits.person_id,
                  person_visits.pizzeria_id,
                  person_visits.visit_date
           FROM person_visits
           WHERE person_visits.visit_date = '2022-02-01'::date),
     l AS (SELECT person_visits.id,
                  person_visits.person_id,
                  person_visits.pizzeria_id,
                  person_visits.visit_date
           FROM person_visits
           WHERE person_visits.visit_date = '2022-06-01'::date)
    (SELECT r.person_id
     FROM r
     EXCEPT
     SELECT l.person_id
     FROM l)
UNION
(SELECT l.person_id
 FROM l
 EXCEPT
 SELECT r.person_id
 FROM r)
ORDER BY 1;

alter table v_symmetric_union
    owner to postgres;

